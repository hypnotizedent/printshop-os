window.addEventListener('DOMContentLoaded', () => {
  let pricingData;
  let currentSetup = 'NEW', currentInk, currentSize, currentColor;
  const breakpoints = [1,5,10,15,20,25,50,75,100,250,750,1000,2500,5000,7500,10000];
  let multiMode = false;

  async function init() {
    pricingData = await fetch('screenprint_pricing_clean.json').then(r => r.json());
    // detect if JSON has setup branches
    multiMode = 'NEW' in pricingData && 'RESET' in pricingData && 'NOSETUP' in pricingData;
    setupListeners();
    populateSetup();
    populateInk();
    populateSize();
    populateColor();
    updatePrice();
  }

  function setupListeners() {
    document.getElementById('setup').addEventListener('change', () => {
      currentSetup = document.getElementById('setup').value;
      populateInk();
      populateSize();
      populateColor();
      updatePrice();
    });
    document.getElementById('inkType').addEventListener('change', () => {
      currentInk = document.getElementById('inkType').value;
      populateSize();
      populateColor();
      updatePrice();
    });
    document.getElementById('size').addEventListener('change', () => {
      currentSize = document.getElementById('size').value;
      populateColor();
      updatePrice();
    });
    document.getElementById('colors').addEventListener('change', () => {
      currentColor = document.getElementById('colors').value;
      updatePrice();
    });
    document.getElementById('quantity').addEventListener('input', updatePrice);
  }

  function getBranch() {
    if (multiMode) {
      return pricingData[currentSetup] || {};
    } else {
      return pricingData;
    }
  }

  function populateSetup() {
    const setupDD = document.getElementById('setup');
    setupDD.innerHTML = '';
    // Always offer setups (even if JSON single branch)
    ['NEW','RESET','NOSETUP'].forEach(val => {
      const opt = document.createElement('option');
      opt.value = val;
      opt.textContent = val === 'NEW' ? 'New setup' : val === 'RESET' ? 'Resetup' : 'No setup';
      setupDD.appendChild(opt);
    });
    currentSetup = setupDD.value;
  }

  function populateInk() {
    const inkDD = document.getElementById('inkType');
    inkDD.innerHTML = '';
    const branch = getBranch();
    Object.keys(branch).forEach(ink => {
      const opt = document.createElement('option');
      opt.value = ink;
      opt.textContent = ink;
      inkDD.appendChild(opt);
    });
    currentInk = inkDD.value;
  }

  function populateSize() {
    const sizeDD = document.getElementById('size');
    sizeDD.innerHTML = '';
    const branch = getBranch();
    const sizes = branch[currentInk] || {};
    Object.keys(sizes).forEach(sz => {
      const opt = document.createElement('option');
      opt.value = sz;
      opt.textContent = sz;
      sizeDD.appendChild(opt);
    });
    currentSize = sizeDD.value;
  }

  function populateColor() {
    const colorDD = document.getElementById('colors');
    colorDD.innerHTML = '';
    const branch = getBranch();
    const colorsObj = ((branch[currentInk] || {})[currentSize]) || {};
    Object.keys(colorsObj).forEach(c => {
      const opt = document.createElement('option');
      opt.value = c;
      opt.textContent = c + (parseInt(c) > 1 ? ' colors' : ' color');
      colorDD.appendChild(opt);
    });
    currentColor = colorDD.value;
  }

  function updatePrice() {
    const qty = parseInt(document.getElementById('quantity').value) || 1;
    const idx = breakpoints.findIndex(b => qty <= b);
    const branch = getBranch();
    const cell = (((branch[currentInk]||{})[currentSize]||{})[currentColor]) || {};
    let raw = cell.price_breaks && cell.price_breaks[idx] !== undefined
      ? cell.price_breaks[idx] : 0;
    let per = typeof raw === 'string'
      ? parseFloat(raw.replace(/[^0-9.]/g, '')) || 0
      : raw;
    const total = per * qty;
    document.getElementById('price').textContent = `$${total.toFixed(2)}`;
    const detailEl = document.getElementById('price-detail');
    detailEl.style.display = 'block';
    detailEl.textContent = `${qty} × $${per.toFixed(2)}`;
  }

  init();
});