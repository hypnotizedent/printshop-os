window.addEventListener('DOMContentLoaded', () => {
  let pricingData = {};
  let currentInk = '';
  let currentSize = '';
  let currentColors = '';
  let currentSetup = 'NEW';
  const breakpoints = [4,9,14,24,49,74,99,249,499,749,999,2499,4999,7499,9999, Infinity];

  async function loadPricing() {
    try {
      const res = await fetch('./screenprint_pricing_clean.json');
      pricingData = await res.json();
      populateInkTypes();
    } catch (err) {
      console.error('Failed to load pricing:', err);
    }
  }

  function populateInkTypes() {
    const inkDropdown = document.getElementById('inkType');
    inkDropdown.innerHTML = '';
    Object.keys(pricingData).forEach(ink => {
      const opt = document.createElement('option');
      opt.value = ink;
      opt.textContent = ink;
      inkDropdown.appendChild(opt);
    });
    currentInk = inkDropdown.value;
    updateDropdowns();
  }

  document.getElementById('inkType').addEventListener('change', (e) => {
    currentInk = e.target.value;
    updateDropdowns();
  });

  document.getElementById('size').addEventListener('change', (e) => {
    currentSize = e.target.value;
    populateColors();
  });

  document.getElementById('colors').addEventListener('change', (e) => {
    currentColors = e.target.value;
    updatePrice();
  });

  document.getElementById('setup').addEventListener('change', (e) => {
    currentSetup = e.target.value;
    updatePrice();
  });

  document.getElementById('quantity').addEventListener('input', updatePrice);

  function updateDropdowns() {
    const sizes = Object.keys(pricingData[currentInk] || {});
    const sizeDropdown = document.getElementById('size');
    sizeDropdown.innerHTML = '';
    sizes.forEach(sz => {
      const opt = document.createElement('option');
      opt.value = sz;
      opt.textContent = sz;
      sizeDropdown.appendChild(opt);
    });
    currentSize = sizeDropdown.value;
    populateColors();
  }

  function populateColors() {
    const colorsObj = pricingData[currentInk][currentSize] || {};
    const colorDropdown = document.getElementById('colors');
    colorDropdown.innerHTML = '';
    Object.keys(colorsObj).forEach(cnt => {
      const opt = document.createElement('option');
      opt.value = cnt;
      opt.textContent = cnt + (parseInt(cnt) > 1 ? ' colors' : ' color');
      colorDropdown.appendChild(opt);
    });
    currentColors = colorDropdown.value;
    updatePrice();
  }

  function updatePrice() {
    const cell = pricingData[currentInk]?.[currentSize]?.[currentColors] || {};
    const qty = parseInt(document.getElementById('quantity').value) || 1;
    const tierIndex = breakpoints.findIndex(b => qty <= b);
    const perPiece = cell.price_breaks?.[tierIndex] || 0;
    const setupFee = (currentSetup === 'REPEAT' ? cell.RESET : cell.NEW) || 0;
    const total = perPiece * qty + setupFee;
    document.getElementById('price').textContent = `$${total.toFixed(2)}`;
    document.getElementById('price-detail').textContent = `${qty} × $${perPiece.toFixed(2)} + $${setupFee.toFixed(2)} setup`;
  }

  loadPricing();
});